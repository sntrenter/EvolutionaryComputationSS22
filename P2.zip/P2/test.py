import numpy as np

zero = np.zeros(4)
ones = np.ones(4)

print(zero)
print(ones)

zeon = zero + ones

print(zeon)