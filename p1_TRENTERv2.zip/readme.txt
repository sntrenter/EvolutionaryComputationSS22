Sam Trenter
VER: Python 3.8.10


p1.py is the "main" program,

It imports from two other files(that are mine) Recombination.py and player.py

Recombination.py contains my implementation of uniform Crossover and 
also contains a global RECOMBINATION_LIST that will contain all Recombination methods

player.py contians the class player, which I use for the popluation
It also contians any operation that I would need to preform around populations or players


you should be able to run it like so:
linux
./p1.py <command line args if wanting to use them>
windows
python p1.py <command line args if wanting to use them>

let me know if there are issues, I don't expect there to be but my python enviroment is a little weird. 



